# WEEK 8 SE Code of Ethics  

## WEEKLY QUIZ
![](pic/Pasted%20image%2020220917130031.png)
![](pic/Pasted%20image%2020220917130052.png)
![](pic/Pasted%20image%2020220917130108.png)

## software Engineering Code of Ethics
to address the complexity of  moral issues 解决道德问题的复杂性 
https://ethics.acm.org/code-of-ethics/software-engineering-code/
1. ==PUBLIC== Software engineers shall act consistently  with the ==public interest== 软件工程师的行为应符合公共利益
2. ==CLIENT AND EMPLOYER==
3. ==PRODUCT==
4. ==JUDGEMENT==
5. ==MANAGEMENT==
6. ==PROFESSION==
7. ==COLLEAGUES==
8. ==SELF==